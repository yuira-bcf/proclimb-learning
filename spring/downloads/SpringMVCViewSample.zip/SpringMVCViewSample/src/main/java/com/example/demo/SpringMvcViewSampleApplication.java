package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringMvcViewSampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringMvcViewSampleApplication.class, args);
	}

}
