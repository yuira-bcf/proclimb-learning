package com.example.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HelloViewController {

    @GetMapping("/hello/model")
    public String helloView(Model model) {
        model.addAttribute("msg", "タイムリーフ!!!");
        return "helloThymeleaf";
    }

    @GetMapping("/hello/modelandview")
    public ModelAndView helloView2() {
        ModelAndView mav = new ModelAndView();
        mav.setViewName("helloThymeleaf");
        mav.addObject("msg", "ModelAndViewから!!!");
        return mav;
    }
}
