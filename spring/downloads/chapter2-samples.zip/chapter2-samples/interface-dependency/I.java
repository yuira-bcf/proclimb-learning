// インターフェース I
public interface I {
    void methodX();
}
