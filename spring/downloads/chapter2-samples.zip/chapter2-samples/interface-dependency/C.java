// クラス C（インターフェース I を実装）
public class C implements I {
    @Override
    public void methodX() {
        System.out.println("Cの処理");
    }
}
