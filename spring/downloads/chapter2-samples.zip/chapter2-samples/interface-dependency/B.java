// クラス B（インターフェース I を実装）
public class B implements I {
    @Override
    public void methodX() {
        System.out.println("Bの処理");
    }
}
