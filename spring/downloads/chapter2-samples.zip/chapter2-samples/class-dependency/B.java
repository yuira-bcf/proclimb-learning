// クラス B（使われる側）
public class B {
    public void methodX() {
        System.out.println("Bの処理");
    }
}
