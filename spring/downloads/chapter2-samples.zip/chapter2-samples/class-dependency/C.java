// クラス C（別の実装）
public class C {
    public void methodX() {
        System.out.println("Cの処理");
    }
}
