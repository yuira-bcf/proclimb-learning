package com.example.demo.used;

/**
 * 挨拶インターフェース
 */
public interface Greet {
    /**
     * 挨拶を返す
     * @return 挨拶
     */
    String greeting();
}
