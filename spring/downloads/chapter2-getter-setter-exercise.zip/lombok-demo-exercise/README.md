# Lombok Demo - 演習用

Getter/SetterとLombokの使い方を学習するためのサンプルプロジェクト（演習用）です。

## プロジェクト構成

```
src/main/java/com/example/lombokdemo/
├── withoutsetter/      - 演習1: Setterなし（直接アクセス）
├── withsetter/         - 演習2: Setterあり（バリデーション付き）
├── withoutgetter/      - 演習3: Getterなし（フィールド直接結合）
├── withgetter/         - 演習4: Getterあり（カスタムGetter）
├── withoutlombok/      - 演習5: Lombok使用前（手動でGetter/Setter）
├── withlombok/         - 演習6: Lombok使用後（@Getter/@Setter）
└── lombokcustom/       - 演習7: Lombokとカスタムメソッドの組み合わせ
```

## 演習の進め方

各パッケージ内のJavaファイルには`TODO`コメントがあります。
指示に従ってコードを記述してください。

### 1. withoutsetter パッケージ
**学習ポイント**: publicフィールドの問題点

- `User.java`: publicフィールドを定義
- `Main.java`: フィールドに直接アクセスして値を設定

### 2. withsetter パッケージ
**学習ポイント**: Setterによるバリデーション

- `User.java`: privateフィールドとバリデーション付きSetterを実装
- `Main.java`: Setter経由で値を設定

### 3. withoutgetter パッケージ
**学習ポイント**: Getterがない場合のコード重複

- `User.java`: publicフィールドを定義
- `Main.java`: 同じ処理を繰り返し記述

### 4. withgetter パッケージ
**学習ポイント**: カスタムGetterによるコード共通化

- `User.java`: privateフィールドとカスタムGetterを実装
- `Main.java`: Getterを使用してコードを簡潔に

### 5. withoutlombok パッケージ
**学習ポイント**: 手動でのGetter/Setter実装の冗長さ

- `User.java`: すべてのGetter/Setterを手動で実装
- `Main.java`: 通常通り使用

### 6. withlombok パッケージ
**学習ポイント**: Lombokによる自動生成

- `User.java`: @Getter/@Setterアノテーションを使用
- `Main.java`: 通常通り使用（自動生成されたメソッドを利用）

### 7. lombokcustom パッケージ
**学習ポイント**: Lombokとカスタムメソッドの組み合わせ

- `User.java`: Lombokの自動生成とカスタムメソッドを併用
- `Main.java`: 両方のメソッドを使用

## VSCodeでの実行方法

1. 実行したいMain.javaを開く
2. エディタ内で右クリック → 「Run Java」を選択

または

- エディタ右上の▶️（Run）ボタンをクリック

## 使用技術

- Java 17
- Spring Boot 3.2.0
- Lombok
- Maven

## ヒント

- 各演習のコード例は、教材の「Lombokの使用例」セクションを参照してください
- わからない場合は、完全版のZIPファイルを確認してください
