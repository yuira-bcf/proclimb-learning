package com.example.lombokdemo.withsetter;

public class Main {
    public static void main(String[] args) {
        // TODO: Userオブジェクトを作成し、Setter経由で値を設定してください
        // 正常な値と不正な値を両方試して、バリデーションが機能することを確認してください
    }
}
