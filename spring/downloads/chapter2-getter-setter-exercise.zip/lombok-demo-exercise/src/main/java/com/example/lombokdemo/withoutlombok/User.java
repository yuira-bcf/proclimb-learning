package com.example.lombokdemo.withoutlombok;

public class User {
    // TODO: privateフィールドを定義してください
    // name (String型), age (int型)

    // TODO: すべてのフィールドに対してGetter/Setterを手動で実装してください
    // getName(), setName(String name)
    // getAge(), setAge(int age)
}
