package com.example.lombokdemo.withoutgetter;

public class Main {
    public static void main(String[] args) {
        // TODO: Userオブジェクトを作成してlastNameとfirstNameに値を設定してください
        // フルネームを表示するために、複数の場所で文字列結合を行ってください
        // （コードの重複が発生することを確認してください）
    }
}
