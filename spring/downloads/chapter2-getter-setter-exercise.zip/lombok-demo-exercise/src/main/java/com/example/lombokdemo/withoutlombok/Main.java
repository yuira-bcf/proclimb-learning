package com.example.lombokdemo.withoutlombok;

public class Main {
    public static void main(String[] args) {
        // TODO: Userオブジェクトを作成し、Setter経由で値を設定してください
        // Getterを使って値を取得し、表示してください
    }
}
