package com.example.lombokdemo.withgetter;

public class Main {
    public static void main(String[] args) {
        // TODO: Userオブジェクトを作成してください（コンストラクタで値を渡す）
        // getFullName()メソッドを複数回呼び出して、フルネームを表示してください
    }
}
