package com.example.lombokdemo.withsetter;

public class User {
    // TODO: privateフィールドを定義してください
    // name (String型), age (int型)

    // TODO: Getter/Setterメソッドを実装してください
    // Setterには適切なバリデーションを追加してください
    // - name: nullや空文字をチェック
    // - age: 0以上150以下の範囲をチェック
}
