package com.example.lombokdemo.lombokcustom;

// TODO: Lombokのアノテーションをインポートしてください
// import lombok.Getter;
// import lombok.Setter;

// TODO: @Getterと@Setterアノテーションを追加してください

public class User {
    // TODO: privateフィールドを定義してください
    // lastName (String型), firstName (String型), age (int型)

    // TODO: カスタムSetter（バリデーション付き）を実装してください
    // setAge(int age) - 0以上150以下の範囲チェック
    // ※ このメソッドはLombokの自動生成より優先されます

    // TODO: カスタムGetterを実装してください
    // getFullName() - lastNameとfirstNameを結合して返す
    // ※ これは新しいメソッドとして追加されます
}
