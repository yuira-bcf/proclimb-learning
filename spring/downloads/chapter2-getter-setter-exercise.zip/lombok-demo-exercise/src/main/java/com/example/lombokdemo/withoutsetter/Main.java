package com.example.lombokdemo.withoutsetter;

public class Main {
    public static void main(String[] args) {
        // TODO: Userオブジェクトを作成し、フィールドに直接値を代入してください
        // 正常な値と不正な値（空文字、負の値）の両方を試してください
    }
}
