package com.example.lombokdemo.withoutgetter;

public class User {
    // TODO: publicフィールドを定義してください
    // lastName (String型), firstName (String型)
}
