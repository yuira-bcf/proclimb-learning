package com.example.lombokdemo.withgetter;

public class User {
    // TODO: privateフィールドを定義してください
    // lastName (String型), firstName (String型)

    // TODO: コンストラクタを実装してください
    // public User(String lastName, String firstName)

    // TODO: Getterメソッドを実装してください
    // getLastName(), getFirstName()

    // TODO: カスタムGetterを実装してください
    // getFullName() - lastNameとfirstNameを結合して返す
}
