package com.example.lombokdemo.withoutsetter;

public class User {
    // TODO: publicフィールドを定義してください
    // name (String型)
    // age (int型)
}
