package com.example.lombokdemo.withlombok;

// TODO: Lombokのアノテーションをインポートしてください
// import lombok.Getter;
// import lombok.Setter;

// TODO: @Getterと@Setterアノテーションを追加してください

public class User {
    // TODO: privateフィールドを定義してください
    // name (String型), age (int型)
    // ※ Getter/Setterは自動生成されます
}
