package com.example.lombokdemo.lombokcustom;

public class Main {
    public static void main(String[] args) {
        // TODO: Userオブジェクトを作成してください
        // Lombokが自動生成したSetterを使って値を設定してください
        // カスタムSetterでバリデーションが機能することを確認してください
        // カスタムGetterを使ってフルネームを表示してください
    }
}
