/**
 * Lombok + カスタムメソッドの使用例
 *
 * 【実行方法】
 * javac -cp lombok.jar *.java
 * java Main
 *
 * 【実行結果】
 * 田中
 * 25
 * 田中 太郎
 *
 * 【注意】このファイルはLombokライブラリが必要です
 */
public class Main {
    public static void main(String[] args) {
        User user = new User();

        // Lombokが自動生成したSetter
        user.setLastName("田中");
        user.setFirstName("太郎");

        // カスタムSetter（バリデーション付き）
        user.setAge(25);    // OK：設定される
        user.setAge(-5);    // NG：無視される

        // Lombokが自動生成したGetter
        System.out.println(user.getLastName());   // 田中
        System.out.println(user.getAge());        // 25

        // カスタムGetter（加工した値を返す）
        System.out.println(user.getFullName());   // 田中 太郎
    }
}
