/**
 * Lombokを使う場合のメインクラス
 * 呼び出し側のコードはLombokなしの場合と全く同じ
 *
 * 【実行方法】
 * javac -cp lombok.jar *.java
 * java Main
 *
 * 【実行結果】
 * 田中太郎
 * 25
 *
 * 【注意】このファイルはLombokライブラリが必要です
 */
public class Main {
    public static void main(String[] args) {
        User user = new User();

        // Lombokあり・なしに関わらず、使い方は同じ
        user.setName("田中太郎");
        user.setAge(25);

        System.out.println(user.getName());  // 田中太郎
        System.out.println(user.getAge());   // 25
    }
}
