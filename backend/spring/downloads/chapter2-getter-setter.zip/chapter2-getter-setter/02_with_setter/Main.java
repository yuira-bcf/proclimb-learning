/**
 * Setterを使う場合のメインクラス
 *
 * 【実行方法】
 * javac *.java
 * java Main
 *
 * 【実行結果】
 * 名前: 田中太郎, 年齢: 25
 * 名前: 田中太郎, 年齢: 25
 */
public class Main {
    public static void main(String[] args) {
        User user = new User();
        user.setName("田中太郎");  // OK
        user.setAge(25);           // OK
        System.out.println("名前: " + user.getName() + ", 年齢: " + user.getAge());

        // 不正な値は設定されない（バリデーションで拒否）
        user.setName("");   // 無視される
        user.setAge(-5);    // 無視される ← データが保護される
        System.out.println("名前: " + user.getName() + ", 年齢: " + user.getAge());
    }
}
