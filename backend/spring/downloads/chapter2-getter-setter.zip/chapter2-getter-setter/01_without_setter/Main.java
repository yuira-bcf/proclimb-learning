/**
 * Setterを使わない場合のメインクラス
 *
 * 【実行方法】
 * javac *.java
 * java Main
 *
 * 【実行結果】
 * 名前: 田中太郎, 年齢: 25
 * 名前: , 年齢: -5
 */
public class Main {
    public static void main(String[] args) {
        User user = new User();
        user.name = "田中太郎";  // 直接代入
        user.age = 25;
        System.out.println("名前: " + user.name + ", 年齢: " + user.age);

        // 問題：不正な値もそのまま設定されてしまう
        user.name = "";     // 空文字もOK
        user.age = -5;      // 負の値もOK ← バグの原因になる
        System.out.println("名前: " + user.name + ", 年齢: " + user.age);
    }
}
