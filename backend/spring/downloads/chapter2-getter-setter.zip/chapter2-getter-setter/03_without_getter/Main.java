/**
 * Getterを使わない場合のメインクラス
 *
 * 【実行方法】
 * javac *.java
 * java Main
 *
 * 【実行結果】
 * 田中 太郎
 * 田中 太郎
 */
public class Main {
    public static void main(String[] args) {
        User user = new User();
        user.lastName = "田中";
        user.firstName = "太郎";

        // 問題：フルネームを取得するたびに結合処理を書く必要がある
        String fullName1 = user.lastName + " " + user.firstName;
        System.out.println(fullName1);

        // 別の場所でも同じ処理を書く必要がある（コードの重複）
        String fullName2 = user.lastName + " " + user.firstName;
        System.out.println(fullName2);
    }
}
