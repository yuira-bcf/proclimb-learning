/**
 * Getterを使わない場合の例
 * publicフィールドに直接アクセス
 */
public class User {
    public String lastName;   // publicなので外部から直接アクセス可能
    public String firstName;
}
