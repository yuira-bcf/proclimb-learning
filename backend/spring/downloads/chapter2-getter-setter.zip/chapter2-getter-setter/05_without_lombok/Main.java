/**
 * Lombokを使わない場合のメインクラス
 *
 * 【実行方法】
 * javac *.java
 * java Main
 *
 * 【実行結果】
 * 田中太郎
 * 25
 */
public class Main {
    public static void main(String[] args) {
        User user = new User();

        // Lombokあり・なしに関わらず、使い方は同じ
        user.setName("田中太郎");
        user.setAge(25);

        System.out.println(user.getName());  // 田中太郎
        System.out.println(user.getAge());   // 25
    }
}
