package com.example.thymeleafusage;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ThymeleafUsageSampleApplication {

    public static void main(String[] args) {
        SpringApplication.run(ThymeleafUsageSampleApplication.class, args);
    }

}
