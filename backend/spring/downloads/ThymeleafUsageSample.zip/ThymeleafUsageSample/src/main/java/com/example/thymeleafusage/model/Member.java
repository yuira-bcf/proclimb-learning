package com.example.thymeleafusage.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * メンバー情報を保持するモデルクラス
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Member {
    /** ID */
    private Integer id;
    /** 名前 */
    private String name;
}
