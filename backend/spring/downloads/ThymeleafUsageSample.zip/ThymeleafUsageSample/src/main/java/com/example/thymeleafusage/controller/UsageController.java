package com.example.thymeleafusage.controller;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.example.thymeleafusage.model.Member;

/**
 * Thymeleaf構文サンプル用コントローラー
 * 6-3-2「Thymeleafの使用方法」で紹介されている構文のサンプル
 */
@Controller
public class UsageController {

    /**
     * Thymeleaf構文サンプルページを表示
     */
    @GetMapping("/")
    public String showUsage(Model model) {
        // 02: インライン処理、03-04: 値結合、07: 条件演算子、08-10: 条件分岐用
        model.addAttribute("name", "太郎");

        // 11-12: オブジェクト参照用（単一のMember）
        Member mb = new Member(1, "田中太郎");
        model.addAttribute("mb", mb);

        // 13: List参照用
        List<String> list = Arrays.asList("東", "西", "南", "北");
        model.addAttribute("list", list);

        // 14: Map参照用
        Map<String, Member> map = new HashMap<>();
        map.put("tanaka", new Member(1, "田中一郎"));
        map.put("suzuki", new Member(2, "鈴木二郎"));
        model.addAttribute("map", map);

        // 15-16: 繰り返し用（Memberのリスト）
        List<Member> members = Arrays.asList(
            new Member(1, "太郎"),
            new Member(2, "次郎"),
            new Member(3, "花子")
        );
        model.addAttribute("members", members);

        return "usage";
    }
}
