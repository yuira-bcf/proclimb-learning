package com.example.demo.service;

/**
 * サービスインターフェース
 */
public interface SomeService {
    /**
     * サービス実行
     */
    void doService();
}
