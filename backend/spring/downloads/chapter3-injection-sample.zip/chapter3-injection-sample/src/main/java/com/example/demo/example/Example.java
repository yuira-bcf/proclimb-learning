package com.example.demo.example;

/**
 * サンプル実行インターフェース
 */
public interface Example {
    /**
     * 実行
     */
    void run();
}
