package com.example.lombokdemo.withoutgetter;

public class Main {
    public static void main(String[] args) {
        User user = new User();
        user.lastName = "田中";
        user.firstName = "太郎";

        // 問題：フルネームを取得するたびに結合処理を書く必要がある
        String fullName1 = user.lastName + " " + user.firstName;
        System.out.println(fullName1);

        // 別の場所でも同じ処理を書く必要がある（コードの重複）
        String fullName2 = user.lastName + " " + user.firstName;
        System.out.println(fullName2);
    }
}
