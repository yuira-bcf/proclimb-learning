package com.example.lombokdemo.withgetter;

public class Main {
    public static void main(String[] args) {
        User user = new User("田中", "太郎");

        // Getterを呼ぶだけでフルネームを取得できる
        System.out.println(user.getFullName());

        // どこでも同じメソッドを呼ぶだけ（コードの重複なし）
        System.out.println(user.getFullName());
    }
}
