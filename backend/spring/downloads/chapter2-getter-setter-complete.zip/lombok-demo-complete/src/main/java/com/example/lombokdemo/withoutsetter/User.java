package com.example.lombokdemo.withoutsetter;

public class User {
    public String name;  // publicなので外部から直接アクセス可能
    public int age;
}
