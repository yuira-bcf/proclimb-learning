package com.example.lombokdemo.withsetter;

public class User {
    private String name;  // privateなので外部から直接アクセス不可
    private int age;

    public String getName() { return name; }
    public int getAge() { return age; }

    public void setName(String name) {
        if (name != null && !name.isEmpty()) {
            this.name = name;
        }
    }

    public void setAge(int age) {
        if (age >= 0 && age <= 150) {
            this.age = age;
        }
    }
}
