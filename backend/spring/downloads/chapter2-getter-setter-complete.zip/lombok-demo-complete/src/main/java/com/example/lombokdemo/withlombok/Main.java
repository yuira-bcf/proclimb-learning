package com.example.lombokdemo.withlombok;

public class Main {
    public static void main(String[] args) {
        User user = new User();

        // Lombokあり・なしに関わらず、使い方は同じ
        user.setName("田中太郎");
        user.setAge(25);

        System.out.println(user.getName());  // 田中太郎
        System.out.println(user.getAge());   // 25
    }
}
