package com.example.lombokdemo.withoutgetter;

public class User {
    public String lastName;   // publicなので外部から直接アクセス可能
    public String firstName;
}
