package com.example.lombokdemo.lombokcustom;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class User {
    private String lastName;
    private String firstName;
    private int age;

    // ========================================
    // カスタムSetter：バリデーション付き
    // ========================================
    // Lombokの自動生成より優先される
    public void setAge(int age) {
        if (age >= 0 && age <= 150) {
            this.age = age;
        }
    }

    // ========================================
    // カスタムGetter：加工した値を返す
    // ========================================
    // 新しいメソッドを追加
    public String getFullName() {
        return lastName + " " + firstName;
    }
}
