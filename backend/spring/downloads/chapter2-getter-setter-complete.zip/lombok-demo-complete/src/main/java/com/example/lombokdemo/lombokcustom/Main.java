package com.example.lombokdemo.lombokcustom;

public class Main {
    public static void main(String[] args) {
        User user = new User();

        // Lombokが自動生成したSetter
        user.setLastName("田中");
        user.setFirstName("太郎");

        // カスタムSetter（バリデーション付き）
        user.setAge(25);    // OK：設定される
        user.setAge(-5);    // NG：無視される

        // Lombokが自動生成したGetter
        System.out.println(user.getLastName());   // 田中
        System.out.println(user.getAge());        // 25

        // カスタムGetter（加工した値を返す）
        System.out.println(user.getFullName());   // 田中 太郎
    }
}
