# Lombok Demo - 完全版

Getter/SetterとLombokの使い方を学習するためのサンプルプロジェクトです。

## プロジェクト構成

```
src/main/java/com/example/lombokdemo/
├── withoutsetter/      - Setterなし（直接アクセス）
├── withsetter/         - Setterあり（バリデーション付き）
├── withoutgetter/      - Getterなし（フィールド直接結合）
├── withgetter/         - Getterあり（カスタムGetter）
├── withoutlombok/      - Lombok使用前（手動でGetter/Setter）
├── withlombok/         - Lombok使用後（@Getter/@Setter）
└── lombokcustom/       - Lombokとカスタムメソッドの組み合わせ
```

## 実行方法

各パッケージの`Main.java`を個別に実行してください。

### VSCodeでの実行
1. 実行したいMain.javaを開く
2. エディタ内で右クリック → 「Run Java」を選択

### コマンドラインでの実行
```bash
# withoutsetter パッケージの実行例
./mvnw compile exec:java -Dexec.mainClass="com.example.lombokdemo.withoutsetter.Main"
```

## 学習ポイント

### 1. Setterの役割
- **withoutsetter**: 不正な値が設定されてしまう問題
- **withsetter**: バリデーションによるデータ保護

### 2. Getterの役割
- **withoutgetter**: コードの重複（同じ処理を何度も書く）
- **withgetter**: カスタムGetterでコードを共通化

### 3. Lombokの便利さ
- **withoutlombok**: 手動でGetter/Setterを記述（冗長）
- **withlombok**: @Getter/@Setterで自動生成（簡潔）

### 4. Lombokとカスタムの組み合わせ
- **lombokcustom**: 自動生成とカスタムメソッドの共存
  - 自動生成されたメソッドを使用
  - 必要に応じてカスタムメソッドを追加・上書き

## 使用技術

- Java 17
- Spring Boot 3.2.0
- Lombok
- Maven
